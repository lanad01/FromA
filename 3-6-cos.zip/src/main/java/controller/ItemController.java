package controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.ItemDao;
import model.Fruit;

@Controller
public class ItemController {
	@Autowired
	private ItemDao itemDao;
	@RequestMapping(value="/item/edit.html") 
	//왜 보낼 땐 edit.html인데 여기선 /item/이 붙는가? 이미 url에 저장된 정보이기 때문이다.
	//하지만 저장되어 있다고 콘트롤러가 받을 때 없으면 안된다. url은 엄연히 item/edit.html로 보내는 것이기 때문이다.
	public ModelAndView update(Integer itemId) {
		Fruit item=this.itemDao.findById(itemId);//편집할 과일
		ModelAndView mav=new ModelAndView("update"); //update jsp로 보낼거야.
		mav.addObject(item); // 근데 여기서 검색한 객체가 함께 가는거야
		return mav;
	}
	
	@RequestMapping(value="/item/delete.html") //맵핑이름이 이거고
	public ModelAndView delete(Integer item_id) { // 콜백으로 return view //매개인자 잘 알아봐야대
		ModelAndView mav=new ModelAndView("delete"); //viewResolver로 앞에 알아서 WEB-INF/jsp가 붙는다
		this.itemDao.delete(item_id);	
		return this.index(); //다시 목록으로
	}
	@RequestMapping(value="/item/confirm.html") //맵핑이름이 이거고
	public ModelAndView confirm(Integer itemId) { // 콜백으로 return view
		ModelAndView mav=new ModelAndView("delete"); //viewResolver로 앞에 알아서 WEB-INF/jsp가 붙는다
		Fruit item=this.itemDao.findById(itemId); // 번호로 과일 검색
		mav.addObject(item); //조회결과를 저장
		System.out.println("그림"+item.getPicture_url());
		mav.addObject("imageName",item.getPicture_url()); //파일이름 저장
		return mav;
	}
	@RequestMapping(value="/item/register.html") //맵핑이름이 이거고
	public ModelAndView register(Fruit fruit, HttpServletRequest request) throws Exception { // 콜백으로 return view
		//Fruit에 저장된 정보를 DB에 삽입, 이미지파일은 업로드
		//업로드 할 때는 절대경로가 필요하다. upload폴더의 절대경로
		//절대경로 획득을 위해 HttpServletRequest가 필요
		ServletContext ctx=request.getSession().getServletContext();
		String filePath=ctx.getRealPath("/upload");
		String encType="euc-kr";
		MultipartRequest multipart=new MultipartRequest(request, filePath, 5*1024*1024,
				encType, new DefaultFileRenamePolicy());
		String pictureUrl=multipart.getFilesystemName("picture_url"); 
		System.out.println("팡리명:"+pictureUrl);
		fruit.setItem_id(Integer.parseInt(multipart.getParameter("item_id")));//번호
		fruit.setItem_name(multipart.getParameter("item_name")); //이름
		fruit.setPrice(Integer.parseInt(multipart.getParameter("price")));
		fruit.setDescription(multipart.getParameter("description"));
		fruit.setPicture_url(pictureUrl);
		
		this.itemDao.create(fruit);
		return index(); // 삽입 후 다시 목록을 띄운다
	}
	@RequestMapping(value="/item/index.html") //맵핑이름이 이거고
	public ModelAndView index() { // 콜백으로 return view
		List<Fruit> itemList=this.itemDao.finaAll();
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("itemList", itemList);
		ModelAndView mav=new ModelAndView("index"); //viewResolver로 앞에 알아서 WEB-INF/jsp가 붙는다
		mav.addAllObjects(map);
		return mav;
	}
	@RequestMapping(value="/item/create.html") //맵핑이름이 이거고
	public ModelAndView create() { // 콜백으로 return view
		ModelAndView mav=new ModelAndView("add");
		mav.addObject(new Fruit());
		return mav;
	}
}

